

    
    function valid()
    {
        
        var user = document.getElementById("user").value;
        var password = document.getElementById("password").value;
        if(user=='hatikva' && password=='leomit1-4')
        {
            document.getElementById("orders").style.display="block";
             document.getElementById("confirm").style.display="none";
        }
        else{
            alert("שם משתמש או סיסמא אינם נכונים")
        }
    }
    
