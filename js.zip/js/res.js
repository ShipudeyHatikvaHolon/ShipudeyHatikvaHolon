


var date = new Date();

var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();

if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;

var today = year + "-" + month + "-" + day;       
document.getElementById("theDate").value = today;


window.addEventListener("DOMContentLoaded", function() {
  var btnPlus = document.querySelector("#btn-plus"),
      btnMinus = document.querySelector("#btn-minus"),
      count = document.querySelector("#count");

  btnPlus.addEventListener("click", changeCounter);
  btnMinus.addEventListener("click", changeCounter);

  function changeCounter() {
    if (this == btnPlus) {
      enableBtn(btnMinus);
      if (count.value >= 9) {
        disableBtn(this);
      }
      else {
        count.value++;
        if (count.value == 9) {
          disableBtn(this);
        }
      }
    }
    if (this == btnMinus) {
      enableBtn(btnPlus);
      if (count.value <= 1) {
        disableBtn(this);
      }
      else {
        count.value--;
        if (count.value == 1) {
          disableBtn(this);
        }
      }
    }
  }

  function disableBtn(btn) {
    btn.style.opacity = .3;
    btn.style.cursor = "default";
  }

  function enableBtn(btn) {
    btn.style.opacity = 1;
    btn.style.cursor = "pointer";
  }
});

