<style>

    .form-deliver-address {
        display: flex;
        justify-content: flex-start;
        flex-wrap: wrap;
    }

    .form-deliver-address .row {
        flex-basis: 28%;
        margin: 20px;   
    }

    .form-deliver-address .row:last-child {

    }

    @media only screen and (max-width: 700px) {
        .form-deliver-address {
            flex-direction: column;
        }
    }

</style>

<div class="form-deliver-address">
    <div class="row">
        <p style="display: none;" class="text-danger" id="addressError">הכתובת הוא שדה חובה</p>
        <label for="address">כתובת:</label>
        <input class="form-control" name="address" type="text" value="<?php echo isset($order['address']) ? $order['address'] : old('address') ?>" placeholder="אנא הזן את הכתובת למשלוח" id="address">
    </div>

    <div class="row">
        <p style="display: none;" class="text-danger" id="addressError">aשם האיש קשר הוא שדה חובה</p>
        <label for="contactName">שם:</label>
        <input class="form-control" type="text" name="contactName" value="<?= isset($order['contactName']) ? $order['contactName'] :  old('contactName') ?>" placeholder="אנא הזן את שם האיש קשר למשלוח" id="contactName">
    </div>

    <div class="row">
        <p style="display: none;" class="text-danger" id="addressError">העיר הוא שדה חובה</p>
        <label for="city">עיר:</label>
        <input class="form-control" type="text" name="city" value="<?=  isset($order['city']) ? $order['city'] : old('city')  ?>" placeholder="אנא הזן את עיר המשלוח" id="city">
    </div>
    
    <div class="row">
        <p style="display: none;" class="text-danger" id="addressError">הקומה הוא שדה חובה</p>
        <label for="floor">קומה:</label>
        <input class="form-control" type="text" name="floor" value="<?=  isset($order['floor']) ? $order['floor'] : old('address')  ?>" placeholder="אנא הזן את הקומה" id="floor">
    </div>

    <div class="row">
        <p style="display: none;" class="text-danger" id="addressError">הדירה הוא שדה חובה</p>
        <label for="apartment">דירה:</label>
        <input class="form-control" type="text" name="apartment" value="<?=  isset($order['apartment']) ? $order['apartment'] : old('apartment')  ?>" placeholder="אנא הזן את הדירה למשלוח" id="apartment">
    </div>
    
    <div class="row">
        <p style="display: none;" class="text-danger" id="addressError">הכניסה הוא שדה חובה</p>
        <label for="entry">כניסה:</label>
        <input class="form-control" type="text" name="entry" value="<?=  isset($order['entry']) ? $order['entry'] : old('entry')  ?>" placeholder="אנא הזן את הכניסה" id="entry">
    </div>

    <div class="row">
        <p style="display: none;" class="text-danger" id="entry">הטלפון של איש הקשר הוא שדה חובה</p>
        <label for="phone">טלפון איש קשר:</label>
        <input class="form-control" type="text" name="phone" value="<?= isset($order['phone']) ? $order['phone'] : old('phone')  ?>" placeholder="אנא הזן את הטלפון של איש הקשר " id="phone">
    </div>
    
    <div class="row">
        <label for="deliverNote">הערות לשליח:</label>
        <textarea class="form-control" type="text" name="deliverNote" placeholder="אנא הזן הערות לשליח במידה ויש" id="deliverNote"> <?=  isset($order['deliverNote']) ? $order['deliverNote'] : old('deliverNote')  ?> </textarea>
    </div>    
</div>